
========================================================================

   Forex Dataset -- Automated Trading Experiment
        By Mathieu Guillame-Bert
        mathieu.guillame-bert@inria.fr
        http://www-prima.inrialpes.fr/guillame-bert/

    Dataset available at http://www-prima.inrialpes.fr/guillame-bert/

========================================================================

Thank you for downloading the "Forex Dataset -- Automated Trading Experiment" dataset.
This document explains how the dataset is structured and how to use the tools that were provided to ease its use.
If you have any questions or suggestions please email me at: mathieu.guillame-bert@inria.fr

INTRODUCTION

	Begin to read the "forex_into.pdf" file for a quick introduction on the Forex trading.

	This dataset is a record of three years of the EURUSD exchange rate sampled approximately every minute (from June 5 2008 to June 5 2011).
	The dataset contains various indicators (computed from the exchange rate), and discredized events/states on these indicators.

	A "trend" is a tendency of the exchange rate to increase (upward trend) or decrease (downward trend) from a time scale (from decades to minutes).
	The dataset contains events/states describing "up-ward" and "down ward" trends (report to "forex_into.pdf" for more details).

	A python script "evaluate_predictions.py" is provided with the dataset.
	This script takes as input a set of buying/selling order (see below for the file format of order), it evaluates the profits (or lost) of these orders, and it generates an html report.

	The report contains data such as:
		- The sum of the profits
		- The average value of the profits
		- The standard deviation the profits
		- curves mapping the confidence of the order (a "confidence" can be specified for each order) for various metrics
		- Etc.
		
	Order can be organize into a hierarchy of "rule sets" and "predictions".
	This (optional) hierarchy is a good way to compare a large number of predictors (i.e. order generators).
	
	You can use the Event Viewer software available at "http://www-prima.inrialpes.fr/guillame-bert/?page=software" to display the dataset.
	The file "scenario.xml" is an example of layout to display.

DATASET

	The dataset is divided into three one-year-long parts:
		- S2: from 05/01/08 00:00:00 to 05/01/09 00:00:00
		- S3: from 05/01/09 00:00:00 to 05/01/10 00:00:00
		- S5: from 05/01/10 00:00:00 to 05/01/11 00:00:00
		
	For each part, several files are provided (the files are in the directory "forexdata").
	These files contain symbolic time sequences.
	These file contain one event/state by line with the following schema:
		[time] [symbol] [confidence/value]
		
	Example
		10	a	1
		20	b	0.5
		20	a	0.001
		
	The files are (where [?] is the number of the part):
	
		- forex_M1_sort_sub_[?].event
			This file contains the exchange-rate and the various indicators sampled every minute.
			Example:
				1262649600.00000000 EURUSD_MACD_M1_Signal 0.00013239
				1278918900.00000000 EURUSD_BB_M1_Low 1.25829339
				
		- forex_M1_sort_sub_[?]_onlyOpen.event
			This file contains the exchange-rate sampled every minute (same as forex_M1_sort_sub_[?].event).
			Example:
				1262649720.00000000 EURUSD_Open_M1 1.44292000 --> At Unix-time "1262649720", One euro was equivalent to 1.44292 us dollars.
			
		- forex_M30_sort_sub_[?].event
			This file contains the exchange-rate and the various indicators sampled every 30 minutes.
			Example:
				1231113600.00000000 EURUSD_SMMA_M30_60 1.39897600
				1231115400.00000000 EURUSD_Awesome_M30 0.00174088

		- analyse1_sub_[?]_M30_onlySilence.event
			The file contains segments where the Forex market is not active (week-ends) or when there are no data available.
			Example:
				1263591000 state.EURUSD_Open_M30_silence 1
				1263769200 state.EURUSD_Open_M30_silence 0
				1264195800 state.EURUSD_Open_M30_silence 1

		- analyse2_sub_[?]_M30.log
			The file contains events/states generated from the discretization of the indicators/trends sampled every 30 minute
			Example:
				1262649600 event.EURUSD_MACD_M30_Main_CrossUp_0.00025 1
				1262649600 state.EURUSD_MACD_M30_Main_GreaterThan_0.00025 1
				1262649600 state.EURUSD_MACD_M30_Main_Inside_0.00025_0.000375 1
				1284145200.0000000000 state.EURUSD_MACD_M30_Main_minus_EURUSD_MACD_M30_Signal_GreaterThan_-0.0000750000 0
				1284145200.0000000000 state.EURUSD_MACD_M30_Main_minus_EURUSD_MACD_M30_Signal_Inside_-0.0001000000_-0.0000750000 1
	
EVALUATION SCRIPT

The evaluation script "evaluate_predictions.py" is located are the root of the dataset.
The first lines of the script contain various parameters for the evaluation.

The predictions of orders to evaluate should be located in the directory "predictions" and inside a sub-directory starting by "ruleset_".
The predictions can be separated into different files with the extension "*.pred".
Each line of a "*.pred" file describes a buy/sell order.
The format of each line is:
	[time] [order symbol] [confidence] [predictor id]
	
The "time" is the UNIX time of the order (number of seconds since 1970 00:00:00 UTC).
The "confidence" is a value in [0,1]. It is only used to analysis in the report.
If you don't have confidence value, set "confidence" to any value you want (like 0.5).
The "predictor id" is an integer used to describe various sources of order.
It is only used in the report.
If you have only one predictor, set "predictor id" to any value you want (like 0) -- and keep the same value for all orders.
	
The "order symbol" is a string describing the parameter of the order as follow:
event.EURUSD_Open_M30_start_[p or m]Trend_[duration]_[curve]_[anything after that]
The regular expression is "event.EURUSD_Open_M30_start_(?P<dir>\\S)Trend_(?P<time>[0-9\\.-]+)_(?P<curve>[0-9-\\.]+)".

	- [p or m] : Is the direction of the order. "p" means buying, "m" means selling.
	- [duration] : Is the duration (in second) of the order. If the duration is negative, the sign will be inversed (e.g. the duration "-100" is the "100"). This is kept for compatibility issues with some of our software.
	- [curve] is a number that is not taken into account. This is kept for compatibility issues with some of our software.
	- [anything after that] can be anything without spaces or tabulations.
	
Examples of order are given in the "ruleset_1" directory.
Example:
	1285653905.911263	event.EURUSD_Open_M30_start_pTrend_-10800.0000000000_0.0000000833_d_8100.0000000000	0.3301081359386444	6096
	--> Buy at time "1285653905.911263" and sell at time "1285653905.911263 + 10800".
	
The script will generate several files:

	- report_[name of the rule set].html contains the statistical analysis of the profits.
	- global_report.html is a fusion of all the report_[name of the rule set].html files.
	- gain_[name of the rule set].txt is a .csv file that contains the statistical analysis of the different predictors (defined with "predictor id").
	- orders_[name of the rule set].txt is generated is the option "save_orders" is set to true in the "evaluate_predictions.py" file. This file contains for every order the beginning/ending exchange rate and the profit.
	
A simple example of report is given in the "example_report" directory. This report has been generated from the "ruleset_1" predictions.





