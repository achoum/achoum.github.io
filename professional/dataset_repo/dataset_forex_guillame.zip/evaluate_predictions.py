# -*- coding: cp1252 -*-

# ========================================================================
#
#       Forex Dataset -- Automated Trading Experiment
#           By Mathieu Guillame-Bert
#           mathieu.guillame-bert@inria.fr
#           http://www-prima.inrialpes.fr/guillame-bert/
#
#       Dataset available at http://www-prima.inrialpes.fr/guillame-bert/
#
# ========================================================================

from matplotlib.ticker import MaxNLocator
from scipy.stats.mstats import mquantiles
import matplotlib.font_manager as fm

import os, glob
import re
import csv
import time
import pdb

from pylab import *
import numpy as np

exchangeRateSymbol = "EURUSD_Open_M1" # convertion rate symbol

exchangeRate = ["forexdata\\forex_M1_sort_sub_2_onlyOpen.event"  # convertion rate files
                ,"forexdata\\forex_M1_sort_sub_3_onlyOpen.event"
                ,"forexdata\\forex_M1_sort_sub_5_onlyOpen.event"
                ]

silenceSymbol = "state.EURUSD_Open_M30_silence" # "silence" symbol (i.e. when the forex is not active)

silenceFiles = ["forexdata\\analyse1_sub_2_M30_onlySilence.event" # "silence" files
                ,"forexdata\\analyse1_sub_3_M30_onlySilence.event"
                ,"forexdata\\analyse1_sub_5_M30_onlySilence.event"
                ]

outdpi = 100            # resolution of the figures
commition = 0.00010     # commition on transations
leverage = 100000       # Leverage
volume = 1              # ask/bid volume
debug = False           # debug mode (display more information)
save_orders = False     # Save order+stats in a file (can generate a huge file)
use_delay_evaluation = False # delays order (experimental)

if "exchangeRate_events" not in globals():
    exchangeRate_events = []

if "silence_events" not in globals():
    silence_events = []

class TimeValue:
    def __cmp__(self,other):
        return cmp(self.time,other.time)
    def __init__(self):
        self.time = 0;
        self.value = 1;
    def __repr__(self):
        return str((self.time,self.value))

class Order:
    def __init__(self):
        self.idrule = -1
        self.begin = -1
        self.end = -1
        self.buy = True
        self.inputRate = 0
        self.outputRate = 0
        self.gain = 0
        self.money = 0
    def __str__(self):
        return "begin:"+str(self.begin)+" ("+time.strftime("%d %b %y %H:%M:%S",time.gmtime(self.begin))+")"\
               +" end:"+str(self.end)+" ("+time.strftime("%d %b %y %H:%M:%S",time.gmtime(self.end))+")"\
               +" buy:"+str(self.buy)\
               +" inputRate:"+str(self.inputRate)\
               +" outputRate:"+str(self.outputRate)\
               +" gain:"+str(self.gain)\
               +" money:"+str(self.money)\
               +" idrule:"+str(self.idrule)
    def __repr__(self):
        return str(self)
    
def evalOrder(o):
    global exchangeRate_events
    global debug
    global exchangeRateSymbol
    global volume
    global leverage

    beginV = getValue(exchangeRate_events,exchangeRateSymbol,o.begin)
    endV = getValue(exchangeRate_events,exchangeRateSymbol,o.end)

    beginSilence = getValue(silence_events,silenceSymbol,o.begin)
    endSilence = getValue(silence_events,silenceSymbol,o.end)

    o.inputRate = beginV
    o.outputRate = endV

    if False and debug:
        print "begin:",o.begin, " i.e. ", time.strftime("%d %b %y %H:%M:%S",time.gmtime(o.begin))
        print "end:",o.end, " i.e. ", time.strftime("%d %b %y %H:%M:%S",time.gmtime(o.end))
        print "beginV:",beginV
        print "endV:",endV
        
    if o.buy:
        o.gain = endV - beginV - commition
    else:
        o.gain = -(endV - beginV) - commition
        
    if (beginSilence > 0.5) or (endSilence > 0.5):
        o.gain = 0
        
    o.money = o.gain * volume * leverage

def old_getValue(preds,p,t):
    lv = 0
    for e in preds.get(p):
        if e.time<=t:
            lv = e.value
        else:
            break
    return lv

def getValue(preds,p,t):
    m = 0
    M = len(preds.get(p))-1

    while True:
        i = m + (M - m)/2
        if t > (preds.get(p)[i]).time:
            m = i
        else:
            M = i
        if m+1>=M:
            break
    i = m
    lv = (preds.get(p)[i]).value
    return lv

def load(path,verbose=True):
    p = {}
    if verbose:
        print "loading",path

    if not isinstance(path,list):
        path = [path];

    num = 0
            
    for pp in path:
        f = open(pp,"r")
        for l in f:
            c = l.split()
            t = TimeValue()
            t.time = float(c[0])
            if len(c)>2:
                t.value = float(c[2])
            if p.has_key(c[1]):
                p[c[1]].append(t)
            else:
                p[c[1]] = [t]
            num = num + 1
            if num%1000 == 0 :
                print ".",
            #print c[1],t.time,t.value
        if num > 2000 or verbose:
            print "[",num, "elements loaded ]";
        f.close()

    for i,j in p.iteritems():
        j.sort()
        
    return p

def load_exchangeRate():
    global exchangeRate_events
    #print "len(exchangeRate_events):",len(exchangeRate_events)
    if len(exchangeRate_events)==0:
        print "Loading exchangeRate"
        exchangeRate_events = load(exchangeRate)

def load_silence():
    global silence_events
    #print "len(silence_events):",len(silence_events)
    if len(silence_events)==0:
        print "Loading silence"
        silence_events = load(silenceFiles)

def compteStatsAndGraphs(data,group,nof,xLabel = "confidence",useLine=False):
    global outdpi
    prob = [0.10,0.25, 0.5, 0.75,0.90]
    problabel = ["D1","Q1","Q2","Q3","D9"]
    probline = ["k:","k--","k-","k--","k:"]

    reportPath =  os.path.dirname(group) + "\\report_" + os.path.basename(group) + ".html"
    report = open( reportPath,"w+",)
    reportDir = "report_" + os.path.basename(group) + "_file"
    reportDir2 = os.path.dirname(group) + "\\" + reportDir

    print >> report,group,"<br>"
    print group

    outoutDataFile = os.path.dirname(group) + "\\gain_" + os.path.basename(group) + ".txt"
    outoutData = open(outoutDataFile,"w");
    print >> outoutData,"# id\tconf\ttotorder\tprofit/order\ttotprofit\tpercentposprofit"
    for d in data:
        outoutData.write(str(d[0]));    
        outoutData.write("\t"+str(d[1]));
        outoutData.write("\t"+str( len(d[2]) ));
        outoutData.write("\t"+str( mean(d[2]) ));
        outoutData.write("\t"+str( sum(d[2]) ));
        outoutData.write("\t"+str( float(sum(array(d[2])>=0)) / len(d[2]) ));
        outoutData.write("\n");
    outoutData.close()

    try:
        os.mkdir(reportDir2)
    except:
        pass

    f = {'family' : 'Times New Roman','size'   : '10'}
    matplotlib.rc('font',**f)

    matplotlib.rc('lines', linewidth=0.5, color='black')
    matplotlib.rc('axes', linewidth=0.5)
    matplotlib.rc('grid', linewidth=0.25)
    matplotlib.rc('lines', markersize=3)
    matplotlib.rc('lines', markeredgewidth=0.1)

    tg = mean([ sum(d[2]) for d in data])
    print >> report,"av. total gain by rule: ",tg,"<br>"
    print "total gain : ",tg

    to = mean([ len(d[2]) for d in data])
    print >> report,"av. total orders by rule: ",to,"<br>"
    print "total orders : ",to

    av = tg / to
    print >> report,"av. average gain by rule: ",av,"<br>"
    print "av gain : ",av

    av2 = mean([ mean(d[2]) for d in data])
    print >> report,"real av. average gain by rule: ",av,"<br>"
    print "real av gain : ",av

    stdg = mean([ std(d[2]) for d in data])
    print >> report,"av. std gain by rule: ",stdg,"<br>"
    print "std gain : ",stdg

    print >> report,"number of rules : ",nof,"<br>"
    print "number of rules : ",nof

    q = mquantiles([ mean(d[2]) for d in data],prob)
    print >> report,"quantiles for av. gain : ",prob," : ",q,"<br>"
    print "quantiles for av. gain : ",q

    q = mquantiles([ sum(d[2]) for d in data],prob)
    print >> report,"quantiles for total gain : ",prob," : ",q,"<br>"
    print "quantiles for total gain : ",q

    q = mquantiles([ len(d[2]) for d in data],prob)
    print >> report,"quantiles for num of order : ",prob," : ",q,"<br>"
    print "quantiles for num of order : ",q

    if len(data)==0:
        return reportPath

    #=============all data=================
    
    div = 20
    confs = linspace(0.3,1,div)
    confs2 = confs[:-1]
    b1 = 0.25
    b2 = 0.1
    border = (b1,b1,1-b1-b2,1-b1-b2)

    def f(x):
        if x:
            return [0,0,1]
        else:
            return [1,0,0]
        
    c_color = [ f(sum(d[2])>=0) for d in data]

    def genFig():
        fig = figure(facecolor=None,edgecolor='k',figsize=(3+1,2.5))
        fig.patch.set_alpha(0)
        return fig

    print >> report, "<TABLE BORDER=\"0\">"
    print >> report, "<TR><TH>"

    numXLabels = 4
    
    #======= nuage : conf/orders =====

    fig = genFig()
    ax = fig.add_axes(border)
    
    #ax.set_xlim([0,1])
    ax.set_xlabel(xLabel)
    ax.set_ylabel('total num. orders')
    ax.xaxis.set_major_locator(MaxNLocator(numXLabels))
    ax.yaxis.set_major_locator(MaxNLocator(5))

    if useLine:
        ax.plot([ d[1] for d in data],[ len(d[2]) for d in data])
    else:
        ax.scatter([ d[1] for d in data],[ len(d[2]) for d in data],facecolors=c_color,edgecolors=c_color,s=3,linewidths=0)

    n = "point_conf_order.png"
    fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    report.write("<img src=\"" + reportDir + "/" +n+ "" + "\" border=\"0\" align=\"center\"></img>")

    #n = "point_conf_order.svg"
    #fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    close(fig)
    
    #======= bars : conf/orders =====

    fig = genFig()
    ax = fig.add_axes(border)
    
    #ax.set_xlim([0,1])
    ax.set_xlabel(xLabel)
    ax.set_ylabel('total num. orders')
    ax.xaxis.set_major_locator(MaxNLocator(numXLabels))
    ax.yaxis.set_major_locator(MaxNLocator(5))


    #=== QUANTIL PLOT ====
    qs = []
    for c in range(0,len(confs)-1):
        dd = []
        for d in data:
            if d[1] >= confs[c] and d[1] < confs[c+1]:
                dd.append(len(d[2]))
        if len(dd)>0:
            q = mquantiles(dd,prob)
        else:
            q = [0,0,0,0,0]
        print q
        qs.append(q)

    meanconf = []
    for i in range(len(confs)-1):
        meanconf.append((confs[i]+confs[i+1])/2)
        
    for i in range(len(prob)):
        ax.plot(meanconf,[ q[i] for q in qs],probline[i],label=problabel[i])

    prop = fm.FontProperties(size=10)
    box = ax.get_position()
    ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])
    ax.legend(loc='center left',frameon=False,prop=prop, bbox_to_anchor=(1, 0.5))
    
    #=== FIN QUANTIL PLOT ====
    
##    bar = []
##    error = []
##    for c in range(0,len(confs)-1):
##        # confs[c] <= conf < confs[c+1]
##        bar.append(mean( [ len(d[2]) for d in data if d[1] >= confs[c] and d[1] < confs[c+1]] ))
##        error.append(std( [ len(d[2]) for d in data if d[1] >= confs[c] and d[1] < confs[c+1]] ))
##     
##    ax.bar(confs2, bar, 1./(div*1.5),color="black",yerr=error,ecolor="red")

    n = "bar_conf_order.png"
    fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    report.write("<img src=\"" + reportDir + "/" +n+ "" + "\" border=\"0\" align=\"center\"></img>")

    n = "bar_conf_order.svg"
    fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    close(fig)

    #======= nuage : conf/averageGain =====

    fig = genFig()
    ax = fig.add_axes(border)
    
    #ax.set_xlim([0,1])
    ax.set_xlabel(xLabel)
    ax.set_ylabel('profit/order($)')
    ax.xaxis.set_major_locator(MaxNLocator(numXLabels))
    ax.yaxis.set_major_locator(MaxNLocator(5))

    if useLine:
        ax.plot([ d[1] for d in data],[ mean(d[2]) for d in data])
    else:
        ax.scatter([ d[1] for d in data],[ mean(d[2]) for d in data],facecolors=c_color,edgecolors=c_color,s=3,linewidths=0)

    n = "point_conf_avGain.png"
    fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    report.write("<img src=\"" + reportDir + "/" +n+ "" + "\" border=\"0\" align=\"center\"></img>")

    #n = "point_conf_avGain.svg"
    #fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    close(fig)
    
    #======= bars : conf/averageGain =====

    fig = genFig()
    ax = fig.add_axes(border)

    ax.set_xlabel(xLabel)
    ax.set_ylabel('profit/order($)')
    ax.xaxis.set_major_locator(MaxNLocator(numXLabels))
    ax.yaxis.set_major_locator(MaxNLocator(5))

    #=== QUANTIL PLOT ====
    qs = []
    for c in range(0,len(confs)-1):
        dd = []
        for d in data:
            if d[1] >= confs[c] and d[1] < confs[c+1]:
                dd.append(mean(d[2]))
        if len(dd)>0:
            q = mquantiles(dd,prob)
        else:
            q = [0,0,0,0,0]
        #print q
        qs.append(q)

    meanconf = []
    for i in range(len(confs)-1):
        meanconf.append((confs[i]+confs[i+1])/2)
        
    for i in range(len(prob)):
        ax.plot(meanconf,[ q[i] for q in qs],probline[i],label=problabel[i])

    prop = fm.FontProperties(size=10)
    box = ax.get_position()
    ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])
    ax.legend(loc='center left',frameon=False,prop=prop, bbox_to_anchor=(1, 0.5))

    #=== FIN QUANTIL PLOT ====

##    bar = []
##    error = []
##    for c in range(0,len(confs)-1):
##        # confs[c] <= conf < confs[c+1]
##        dd = [ mean(d[2]) for d in data if d[1] >= confs[c] and d[1] < confs[c+1]]
##        #bar.append(mean(dd))
##        #error.append(std(dd))
##        if len(dd)>0:
##            ax.boxplot(dd,positions=[(confs[c]+confs[c+1])/2],widths=(confs[c+1]-confs[c]))
##    
    #ax.bar(confs2, bar, 1./(div*1.5),color="black",yerr=error,ecolor="red")

    n = "bar_conf_avGain.png"
    fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    report.write("<img src=\"" + reportDir + "/" +n+ "" + "\" border=\"0\" align=\"center\"></img>")

    n = "bar_conf_avGain.svg"
    fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    close(fig)
    
    #======= nuage : conf/profit total =====

    fig = genFig()
    ax = fig.add_axes(border)
    
    #ax.set_xlim([0,1])
    ax.set_xlabel(xLabel)
    ax.set_ylabel('total profit($)')
    ax.xaxis.set_major_locator(MaxNLocator(numXLabels))
    ax.yaxis.set_major_locator(MaxNLocator(5))

    if useLine:
        ax.plot([ d[1] for d in data],[ sum(d[2]) for d in data])
    else:
        ax.scatter([ d[1] for d in data],[ sum(d[2]) for d in data],facecolors=c_color,edgecolors=c_color,s=3,linewidths=0)

    n = "point_conf_totGain.png"
    fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    report.write("<img src=\"" + reportDir + "/" +n+ "" + "\" border=\"0\" align=\"center\"></img>")

    #n = "point_conf_totGain.svg"
    #fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    close(fig)
    
    #======= bar : conf/profit total =====

    fig = genFig()
    ax = fig.add_axes(border)

    ax.set_xlabel(xLabel)
    ax.set_ylabel('total profit($)')
    ax.xaxis.set_major_locator(MaxNLocator(numXLabels))
    ax.yaxis.set_major_locator(MaxNLocator(5))

    #=== QUANTIL PLOT ====
    qs = []
    for c in range(0,len(confs)-1):
        dd = []
        for d in data:
            if d[1] >= confs[c] and d[1] < confs[c+1]:
                dd.append(sum(d[2]))
        if len(dd)>0:
            q = mquantiles(dd,prob)
        else:
            q = [0,0,0,0,0]
        #print q
        qs.append(q)

    meanconf = []
    for i in range(len(confs)-1):
        meanconf.append((confs[i]+confs[i+1])/2)
        
    for i in range(len(prob)):
        ax.plot(meanconf,[ q[i] for q in qs],probline[i],label=problabel[i])

    prop = fm.FontProperties(size=10)
    box = ax.get_position()
    ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])
    ax.legend(loc='center left',frameon=False,prop=prop, bbox_to_anchor=(1, 0.5))

    #=== FIN QUANTIL PLOT ====

##    bar = []
##    error = []
##    for c in range(0,len(confs)-1):
##        # confs[c] <= conf < confs[c+1]
##        dd = [ sum(d[2]) for d in data if d[1] >= confs[c] and d[1] < confs[c+1]]
##        bar.append(mean( dd ))
##        error.append(std( dd ))
##    
##    ax.bar(confs2, bar, 1./(div*1.5),color="black",yerr=error,ecolor="red")

    n = "bar_conf_totGain.png"
    fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    report.write("<img src=\"" + reportDir + "/" +n+ "" + "\" border=\"0\" align=\"center\"></img>")

    n = "bar_conf_totGain.svg"
    fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    close(fig)
    
    #======= nuage : conf/positive =====
    fig = genFig()
    ax = fig.add_axes(border)
    
    ax.set_xlabel(xLabel)
    ax.set_ylabel('percentage of positive profit')
    ax.xaxis.set_major_locator(MaxNLocator(numXLabels))
    ax.yaxis.set_major_locator(MaxNLocator(5))

    if useLine:
        ax.plot([ d[1] for d in data],[ float(sum(array(d[2])>0)) / len(d[2]) for d in data])
    else:
        ax.scatter([ d[1] for d in data],[ float(sum(array(d[2])>0)) / len(d[2]) for d in data],facecolors=c_color,edgecolors=c_color,s=3,linewidths=0)

    n = "point_conf_pos.png"
    fig.savefig(reportDir2+ "/" +n,dpi=outdpi)
    report.write("<img src=\"" + reportDir + "/" +n+ "" + "\" border=\"0\" align=\"center\"></img>")
    close(fig)
    #n = "point_conf_pos.svg"
    #fig.savefig(reportDir2+ "/" +n,dpi=outdpi)

    print >> report, "</TH></TR></TABLE> "

    print >> report,"<script src='sorttable.js'></script>"

    if(len(data)<1000):
        print >> report, "<table width='100%' class='sortable' align='center' border='1px' width='50%' style='text-align:center;font-size:small;border-collapse:collapse;'>"
        print >> report, "<tr>"
        print >> report, "<td>name</td>"
        print >> report, "<td>conf</td>"
        print >> report, "<td>noc</td>"
        print >> report, "<td>avgain</td>"
        print >> report, "<td>stdgain</td>"
        print >> report, "<td>totalgain</td>"
        print >> report, "</tr>"
        for d in data:
            print >> report, "<tr>"
            print >> report, "<td>",d[0],"</td>";
            print >> report, "<td>",d[1],"</td>";
            print >> report, "<td>",len(d[2]),"</td>";
            print >> report, "<td>",mean(d[2]),"</td>";
            print >> report, "<td>",std(d[2]),"</td>";
            print >> report, "<td>",sum(d[2]),"</td>";
            print >> report, "</tr>"
        print >> report, "</table>"
    report.close()
    return reportPath

class Rule:
    def __init__(self):
        id = -1
        conf = -1
        cov = -1
        std = -1

def eval_Rules(group,mode):

    print "group :",group

    reportPath =  os.path.dirname(group) + "\\report_" + os.path.basename(group) + ".html"
    saveOrdersPath =  os.path.dirname(group) + "\\orders_" + os.path.basename(group) + ".txt"

    print "reportPath:",reportPath
    print "saveOrdersPath:",saveOrdersPath

    if os.path.exists(reportPath):
        print "already existing report"
        return reportPath

    if save_orders:
        f2 = open(saveOrdersPath,"w")  ## save orders

    rules = {}
    try:
        ff = open(group+"\\total_data.txt", 'rb')
        ruleData = csv.reader(ff, delimiter='\t', quotechar='|')
        print "load rules stat"
        ruleData.next()
        for r in ruleData:
            r2 = Rule()
            r2.id = int(r[0])
            r2.conf = float(r[1])
            r2.cov = float(r[2])
            r2.std = float(r[3])
            rules[r2.id] = r2
    except:
        rules = None
        pass

    data = []

    print "load predictions"

    predictionsFiles = glob.glob(group+"\\*.pred")
    print "number of prediciton files: ",len(predictionsFiles)

    xlabel = "confidence"
    useLine = False
        
    index = 0
    lastClock = 0
    for f in predictionsFiles:
        index = index + 1

        #if index>2000: # debug
        #    print "!DEBUG!"
        #    break
        
        orders = []
        g = re.search("prediction_rule_(?P<id>[0-9]+)\.pred",f)
        if g!=None:
            id = int(g.group("id"))
        else:
            id = f

        if debug:
            print "load prediction",
        predictions = load(f,False)

        numLoaded = sum([len(b) for b in predictions.values()])

        if numLoaded > 2000 or lastClock + 1 < time.clock() or debug:
            print "[",index,"/",len(predictionsFiles),"]"
            lastClock = time.clock()

        for (p,e2) in predictions.iteritems():
            #print "Prediction : ", p

            if not use_delay_evaluation:
                g = re.match("event.EURUSD_Open_M30_start_(?P<dir>\\S)Trend_(?P<time>[0-9\\.-]+)_(?P<curve>[0-9-\\.]+)",p) # ajouter $
                if g!=None:
                    for e in e2:
                        o = Order()
                        o.buy = (g.group("dir")=="p")
                        o.begin = e.time
                        o.end = o.begin + fabs(float(g.group("time")))
                        o.idrule = id
                        orders.append(o)
            else:
                g = re.match("event.EURUSD_Open_M30_start_(?P<dir>\\S)Trend_(?P<time>[0-9\\.-]+)_(?P<curve>[0-9-\\.]+)_d_(?P<delay>[0-9-\\.]+)$",p)  # ajouter $
                if g!=None:
                    for e in e2:
                        o = Order()
                        o.buy = (g.group("dir")=="p")
                        o.begin = e.time
                        o.end = o.begin + fabs(float(g.group("time"))) - float(g.group("delay"))
                        o.idrule = id
                        orders.append(o)

        if debug:
            print len(orders),"orders"
            
        if len(orders)>0:
            moneyList = []
            for o in orders:
                evalOrder(o)
                moneyList.append(o.money)
                
            if rules!=None:
                data.append((id,rules[id].conf,moneyList,rules[id]))
            else:
                data.append((id,0.5,moneyList,None))

        #============ save orders
        if save_orders:
            for o in orders:
                print >> f2 , str(o)

    if save_orders:
        f2.close()
    print "gen stats"

    return compteStatsAndGraphs(data,group,len(predictionsFiles),xlabel,useLine=useLine)

def analyse(base):
    groupDir = base+"*"
    groups = glob.glob(groupDir)

    globalReport = base+"global_report.html"
    f = open(globalReport,"w+")

    for g in groups:
        
        if re.search("report_",g)!=None:
            continue
        if re.search("ignior_",g)!=None:
            continue
        if re.search("gain_",g)!=None:
            continue
        if re.search("save",g)!=None:
            continue
        if re.search("orders_",g)!=None:
            continue
        if re.search("sorttable.js",g)!=None:
            continue
        
        if not re.search("rules_",g)!=None and not re.search("ruleset_",g)!=None:
            continue
            
        reportPath = eval_Rules(g,1)

        if reportPath!=None:
            f2 = open(reportPath,"r")
            for l in f2:
                f.write(l)
                f.write("\n")
            f2.close()
            f.write("<hr>\n")
            f.flush()

    f.close()

if __name__ == "__main__":


    print " ========================================================================";
    print "";
    print "       Evaluate Predictions for Forex Forcasting";
    print "           By Mathieu Guillame-Bert";
    print "           mathieu.guillame-bert@inria.fr";
    print "           http://www-prima.inrialpes.fr/guillame-bert/";
    print "";
    print "       Dataset available at http://www-prima.inrialpes.fr/guillame-bert/";
    print "";
    print " ========================================================================";
    print "";

    load_exchangeRate()
    load_silence()

    analyse("predictions\\")

    print "done"
    
