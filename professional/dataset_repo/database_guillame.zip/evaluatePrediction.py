# -*- coding: cp1252 -*-

# evaluatePrediction.py
# by Mathieu Guillame-Bert
# PhD Student - INRIA Rh�ne Alpes
# Mail : mathieu.guillame-bert@inrialpes.fr
# Web site : http://www-prima.imag.fr/guillame-bert

from Tkinter import *
import tkFileDialog
import tkMessageBox
import re
import os
import glob
import StringIO
import numpy as np
import pdb
import time
import random
import math
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

# figures' parameters
b1 = 0.25
b2 = 0.1
border = (b1,b1,1-b1-b2,1-b1-b2)
statsNum = 0
computeSurceIntersection = False

# [debug mode) generage some fake data
debug = False

class Prediction:
    def __cmp__(self,other):
        return cmp(self.begin,other.begin)
    def __repr__(self):
        return str((self.begin,self.end,self.symbol,self.confidence))
    def __init__(self):
        self.begin = 0
        self.end = 0
        self.symbol = 0
        self.confidence = 0
    def precision(self):
        return math.sqrt(((self.end - self.begin)**2)/12)
        #return self.end - self.begin
    
Prediction.precisionType = "Standard deviation"
Prediction.precisionTypeMin = "standard deviation"

#Prediction.precisionType = "Range"
#Prediction.precisionTypeMin = "range"

def strPercent(v):
    if type(v)==str:
        return v
    else:
        return "%.2f%%"%(100*v)
    
class PB:
    def __init__(self, title,width, height):
        self.__root = Toplevel()
        self.__root.resizable(False, False)
        self.__root.title(title)
        self.__canvas = Canvas(self.__root, width=width, height=height)
        self.__canvas.grid()
        self.__width = width
        self.__height = height

    def title(self,title):
        self.__root.title(title)

    def open(self):
        self.__root.deiconify()

    def close(self):
        self.__root.withdraw()

    def update(self, ratio):
        self.__canvas.delete(ALL)
        self.__canvas.create_rectangle(0, 0, self.__width * ratio, \
                                       self.__height, fill='blue')
        self.__canvas.create_text(self.__width * 0.5, self.__height*0.5, text=strPercent(ratio))
        self.__root.update()
    
def printValue(o,name,value,printDots=True,color = None,extra=None):
    print >>o, "<tr><td valign=\"top\"><strong> "
    if color!=None:
        print >>o, "<font color=\"" + color + "\">"
    print >>o,name

    if color!=None:
        print >>o, "</font>"

    print >>o, " </strong> "

    if extra!=None:
        print >>o,"<br>",extra

    print >>o," </td><td>"

    if color!=None:
        print >>o, "<font color=\"" + color + "\">"
    
    if printDots:
        print >>o,"<strong> : </strong>"
    print >>o,value

    if color!=None:
        print >>o, "</font>"

    print >>o," </td></tr>"

class StatAnalisis:
    def __init__(self,l,buildFig=False):

        if len(l)==0:
            self.mean = 0# float('nan')
            self.median = 0# float('nan')
            self.std = 0# float('nan')
            self.min = 0# float('nan')
            self.max = 0# float('nan')
            self.len = 0
            self.fig = None
        else:
            self.mean = np.mean(l)
            self.median = np.median(l)
            self.std = np.std(l)
            self.min = np.min(l)
            self.max = np.max(l)
            self.len = len(l)
            if buildFig:
                self.fig = plt.figure(figsize=(6,3))
                ax = self.fig.add_axes(border)
                ax.boxplot(l,vert=0)
                ax.get_yaxis().set_visible(False)
                ax.spines['right'].set_color('none')
                ax.spines['left'].set_color('none')
                ax.spines['top'].set_color('none')
                ax.get_xaxis().set_ticks_position('bottom')
                #for direction in ["left", "right", "bottom", "top"]:
                #    ax.axis[direction].set_visible(False)
            else:
                self.fig = None
            
    def strHtml(self,percent=False,reportImagePath=None,reportImagePathHtml=None):
        output = StringIO.StringIO()
        self.printHtml(output,percent=percent,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml)
        value = output.getvalue()
        output.close()
        return value        
    def printHtml(self,o,percent=False,reportImagePath=None,reportImagePathHtml=None):
        global statsNum
        
        if self.fig!=None and reportImagePath!=None:
            print >>o, "<table border=\"0\">"
            print >>o, "<tr><td>"
            
        
        print >>o, "<table border=\"0\">"
        if percent:
            printValue(o,"mean",strPercent(self.mean))
            printValue(o,"median",strPercent(self.median))
            printValue(o,"std",strPercent(self.std))
            printValue(o,"min",strPercent(self.min))
            printValue(o,"max",strPercent(self.max))
        else:
            printValue(o,"mean",self.mean)
            printValue(o,"median",self.median)
            printValue(o,"std",self.std)
            printValue(o,"min",self.min)
            printValue(o,"max",self.max)
            
        printValue(o,"len",self.len)
        print >>o, "</table>"

        if self.fig!=None and reportImagePath!=None:
            print >>o, "</td><td>"
            statsNum = statsNum + 1
            
            name = "stats_"+str(statsNum)+".png"
            ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
            ppath = os.path.join(reportImagePath,name).replace("\\","/")
                    
            self.fig.savefig(ppath,dpi=50)
            plt.close(self.fig)

            print >>o, "<img src=\""+ppathHtml+"\">"
        
            print >>o, "</td></tr>"
            print >>o, "</table>"

def integerHisto_leftheight(l):
    if len(l)==0:
        return [0],[0]
    left = range(1,max(l)+1)
    totalNum = len(l)
    height = [100*float(len([ 1 for v in l if v >= lit and v < lit+1 ]))/totalNum for lit in left ]
    return left,height
    
integerHistoNum = 0
def integerHisto(reportImagePath,reportImagePathHtml,left,height\
                 ,leftp=None,heightp=None,legend="user",legendp="reference",maxX=None):
    global integerHistoNum
    integerHistoNum = integerHistoNum+ 1
    
    fig = plt.figure(figsize=(6,5))
    ax = fig.add_axes(border)
    
    width = 0.35
    
    if leftp==None:
        left2 = np.array(left)-width/2
    else:
        left2 = np.array(left)-width

    ax.bar(width=width,left=left2,height=height,color = "red",label=legend)
    
    if leftp!=None:
        left2p = np.array(leftp)
        ax.bar(width=width,left=left2p,height=heightp,color = "blue",label=legendp)
        ax.legend()
    
    ax.set_xlabel('value')
    ax.set_ylabel('percentage (%)')
    
    #if maxX!=None:
    #    ax.set_xlim([ax.get_xlim()[0],maxX])
        
    ax.set_ylim([min(0,ax.get_ylim()[0]),max(100,ax.get_ylim()[1])])
    #ax.xaxis.set_major_locator(MaxNLocator(5))
    ax.yaxis.set_major_locator(MaxNLocator(5))
    
    if len(left)<5:
        xtick = left
    else:
        xtick = range(0,left[-1],left[-1]/5) 
    
    ax.set_xticks(xtick)
    
    
    name = "histo_"+str(integerHistoNum)+".png"
    ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
    ppath = os.path.join(reportImagePath,name).replace("\\","/")
                    
    fig.savefig(ppath,dpi=50)
    plt.close(fig)
    return "<img src=\""+ppathHtml+"\"> "


class Predictions:
    def __init__(self):
        self.data = []
        self.maximumRange = 0
        self.begins = []
    def getConfidenceList(self):
        return [i.confidence for i in self.data]
    def getPrecisionList(self):
        return [i.precision() for i in self.data]

    def getIndexOfBefore(self,t):
        if len(self.begins)==0:
            return 0
        m = 0
        M = len(self.begins)-1
        while True:
            i = (m+M)/2
            if t>self.begins[i]:
                m = i+1
            elif t<=self.begins[i]:
                M = i
            if m>=M:
                break;
        #verif = np.searchsorted(self.begins,t)
        #if m!=verif:
        #    pdb.set_trace()
        return m
    def sort(self):
        self.data.sort()
        self.begins = [i.begin for i in self.data]
    def size(self,sym=None):
        if sym==None:
            return len(self.data)
        c = 0
        for i in self.data:
            if i.symbol==sym:
                c = c + 1
        return c
    def loadFromFile(self,path):
        f = open(path,"r")
        print "reading ",path,
        if f==None:
            print "can't open the file :",path
            return
        gg = re.compile("(?P<begin>[-]?([0-9]*\.[0-9]+|[0-9]+))\s+(?P<end>[-]?([0-9]*\.[0-9]+|[0-9]+))\s+(?P<symbol>\S+)\s+(?P<confidence>([0-9]*\.[0-9]+|[0-9]+))")
        for l in f:
            g = gg.search(l)
            if g!=None:
                #print l
                p = Prediction()
                p.begin = float(g.group("begin"))
                p.end = float(g.group("end"))
                p.symbol = g.group("symbol")
                p.confidence = float(g.group("confidence"))

                if debug:
                    p.confidence = random.random()
                    p.end = p.end + random.random() * 5
                
                r = p.end - p.begin
                if r>self.maximumRange:
                    self.maximumRange = r
                self.data.append(p)
        f.close()
        print "done"
        print "sorting ",path,
        self.sort()
        print "done"
    def loadFromFileEvent(self,path):
        f = open(path,"r")
        print "reading ",path,
        if f==None:
            print "can't open the file :",path
            return
        gg = re.compile("(?P<begin>[+-]?([0-9]*\.[0-9]+|[0-9]+))\s+(?P<symbol>\S+)")
        for l in f:
            g = gg.search(l)
            #print l
            #print g.groups()
            if g!=None:
                p = Prediction()
                p.begin = float(g.group("begin"))
                p.end = p.begin
                p.symbol = g.group("symbol")
                p.confidence = 1
                self.data.append(p)
        self.maximumRange = 0
        f.close()
        print "done"
        print "sorting ",path,
        self.sort()
        print "done"

def screenText():
    return \
    "=================================================\n"\
    "evaluatePrediction.py\n"\
    "by Mathieu Guillame-Bert\n"\
    "PhD Student - INRIA Rh�ne Alpes\n"\
    "Mail : mathieu.guillame-bert@inrialpes.fr\n"\
    "Web site : http://www-prima.imag.fr/guillame-bert\n"\
    "=================================================\n"

def screen():
    print screenText()
    
class Report:
    def __init__(self):
        self.name = "noname"
        
    def getValue(self,who,what):
        if who=="user":
            if what=="precision":
                return self.precUser
            if what=="confidence":
                return self.confUser
            if what=="support":
                return self.supportUser
        if who=="ratio user-reference":
            refv = self.getValue("reference",what)
            if refv==0:
                return 0
            else:
                return self.getValue("user",what) / refv
        else:
            if what=="precision":
                return self.precRef
            if what=="confidence":
                return self.confRef
            if what=="support":
                return self.supportRef
        
    def write(self,o,reportImagePath,reportImagePathHtml):
        print >>o, "<table border=\"0\">"
        printValue(o,"Subset",self.name)

        printValue(o,"&nbsp;","&nbsp;",False)

        printValue(o,"Symbol to predict",self.symbol)
        printValue(o,"Number of user predictions",self.nOfUserPred)
        printValue(o,"Number of reference predictions",self.nOfRefPred)
        printValue(o,"Number of reference events",self.nOfRefEvent)
 
        printValue(o,"&nbsp;","&nbsp;",False)
        
        if self.description!=None:
            text = ""
            for i in self.description.iteritems():
                text = text + "<br>"
                text = text + i[0] + " : " + str(i[1])
                
            printValue(o,"Subset complexity description",text)

            printValue(o,"&nbsp;","&nbsp;",False)

        if self.eventsAvalable:
            printValue(o,"User predictions estimated confidence",strPercent(self.confUser))
            printValue(o,"Reference predictions estimated confidence",strPercent(self.confRef))
    
            printValue(o,"User predictions estimated confidence/Reference predictions estimated confidence"
                ,strPercent(self.confUser/self.confRef),color="#FF0000")
    
            printValue(o,"&nbsp;","&nbsp;",False)
            
            printValue(o,"User predictions estimated support",strPercent(self.supportUser))
            printValue(o,"Reference predictions estimated support",strPercent(self.supportRef))
    
            printValue(o,"User predictions estimated support/Reference predictions estimated support"
                ,strPercent(self.supportUser/self.supportRef),color="#FF0000")
    
            printValue(o,"&nbsp;","&nbsp;",False)

        printValue(o,"User predictions precision",self.UserPred_Precision_Stats.mean)
        printValue(o,"Reference predictions precision",self.RefPred_Precision_Stats.mean)

        printValue(o,"User predictions precision/Reference predictions precision"
            ,strPercent(self.UserPred_Precision_Stats.mean/self.RefPred_Precision_Stats.mean),color="#FF0000")

        printValue(o,"&nbsp;","&nbsp;",False)

        if self.eventsAvalable:
            extra = None
            img = integerHisto(reportImagePath,reportImagePathHtml,left=self.userMultiPred_left,height=self.userMultiPred_height\
                               ,leftp=self.refMultiPred_left,heightp=self.refMultiPred_height)
            printValue(o,"Statistics of multiple prediction of a single event"\
                ,img,False,extra=extra)
            
            
            #extra = None
            #img = integerHisto(reportImagePath,reportImagePathHtml,left=self.refMultiPred_left,height=self.refMultiPred_height)
            #printValue(o,"Statistics of multiple reference prediction of a single event"\
            #    ,img,False,extra=extra)
    
            printValue(o,"&nbsp;","&nbsp;",False)

        def graphConfPrec(preds,truth):
            fig = plt.figure(figsize=(6,5))
            ax = fig.add_axes(border)
            if len(preds.data)!=len(truth):
                raise Exception("len(preds.data)!=len(truth) " + str(len(preds.data)) + " " + str(len(truth)))
            
            confs = [ p.confidence for p in preds.data]
            ranges = [ p.precision() for p in preds.data]

            def c(t):
                if t>=0.5:
                    return "blue"
                else:
                    return "red"
            colors = [ c(t) for t in truth ]
            
            if len(confs)!=0:
                ax.scatter(confs,ranges,c=colors,label="_nolegend_")
            #ax.set_yscale('log')
            ax.set_xlabel('confidence')
            ax.set_ylabel(Prediction.precisionTypeMin)
            ax.set_xlim([0,1])

            if len(confs)!=0:
                ax.scatter([confs[0]],[ranges[0]],c=["blue"],label="correct")
                ax.scatter([confs[0]],[ranges[0]],c=["red"],label="incorrect")
                ax.legend(scatterpoints=1)
            
            ax.xaxis.set_major_locator(MaxNLocator(5))
            ax.yaxis.set_major_locator(MaxNLocator(5))
            
            return fig

        if self.eventsAvalable:

            fig = graphConfPrec(self.refPred,self.refCross[1])
            
            name = self.name+"_ref_confRange.png"
            ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
            ppath = os.path.join(reportImagePath,name).replace("\\","/")            
            fig.savefig(ppath,dpi=50)
            plt.close(fig)

            printValue(o,"Confidence/"+Prediction.precisionType+" of reference predictions","<img src=\""+ppathHtml+"\">")
    
            fig = graphConfPrec(self.userPred,self.userCross[1])
            
            name = self.name+"_user_confRange.png"
            ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
            ppath = os.path.join(reportImagePath,name).replace("\\","/")            
            fig.savefig(ppath,dpi=50)
            plt.close(fig)

            printValue(o,"Confidence/"+Prediction.precisionType+" of user predictions","<img src=\""+ppathHtml+"\">")
    
    
            fig = plt.figure(figsize=(4,3))
            ax = fig.add_axes(border)
     
            cats = 5
            width = 1./cats
            left2 = np.arange(0,1,width)
            height = []
            left = []
            for l in left2:
                num = 0
                numg = 0
                for i in range(len(self.refCross[0])):
                   if self.refCross[0][i] >= l and self.refCross[0][i] < l + width:
                       num = num + 1
                       if self.refCross[1][i] >= 0.5:
                           numg = numg + 1
                if num!=0:
                    height.append(float(numg)/num)
                    left.append(l)
            #ax.bar(left, height, width=width)
            tx = []
            ty = []
            for i in range(len(left)):
                tx.append(left[i])
                ty.append(height[i])
                tx.append(left[i]+width)
                ty.append(height[i])
            ax.plot(tx,ty,'-',color="black")
            
            ax.plot(self.refCross[0],self.refCross[1],'.',color="black")
    
            ax.set_xlabel('confidence')
            ax.set_ylabel('succes')
            #ax.set_xlim([-0.2,1.2])
            #ax.set_ylim([-0.2,1.2])
            ax.set_xlim([min(0,ax.get_xlim()[0]),max(1,ax.get_xlim()[1])])
            ax.set_ylim([min(0,ax.get_ylim()[0]),max(1,ax.get_ylim()[1])])
            ax.xaxis.set_major_locator(MaxNLocator(5))
            ax.yaxis.set_major_locator(MaxNLocator(2))
    
            name = self.name+"_refCross.png"
            ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
            ppath = os.path.join(reportImagePath,name).replace("\\","/")            
            fig.savefig(ppath,dpi=50)
            plt.close(fig)
    
            printValue(o,"Confidence/succes rate for reference prediction","<img src=\""+ppathHtml+"\">")
    
            fig = plt.figure(figsize=(4,3))
            ax = fig.add_axes(border)
    
            cats = 5
            width = 1./cats
            left2 = np.arange(0,1,width)
            height = []
            left = []
            for l in left2:
                num = 0
                numg = 0
                for i in range(len(self.userCross[0])):
                   if self.userCross[0][i] >= l and self.userCross[0][i] < l + width:
                       num = num + 1
                       if self.userCross[1][i] >= 0.5:
                           numg = numg + 1
                if num!=0:
                    height.append(float(numg)/num)
                    left.append(l)
            #ax.bar(left, height, width=width)
            tx = []
            ty = []
            for i in range(len(left)):
                tx.append(left[i])
                ty.append(height[i])
                tx.append(left[i]+width)
                ty.append(height[i])
            ax.plot(tx,ty,'-',color="black")
            
            ax.plot(self.userCross[0],self.userCross[1],'.',color="black")
            ax.set_xlabel('confidence')
            ax.set_ylabel('succes')
            #ax.set_xlim([-0.2,1.2])
            #ax.set_ylim([-0.2,1.2])
            ax.set_xlim([min(0,ax.get_xlim()[0]),max(1,ax.get_xlim()[1])])
            ax.set_ylim([min(0,ax.get_ylim()[0]),max(1,ax.get_ylim()[1])])
            ax.xaxis.set_major_locator(MaxNLocator(5))
            ax.yaxis.set_major_locator(MaxNLocator(2))
            
            name = self.name+"_userCross.png"
            ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
            ppath = os.path.join(reportImagePath,name).replace("\\","/")            
            fig.savefig(ppath,dpi=50)
            plt.close(fig)
            
            printValue(o,"Confidence/succes rate for user prediction","<img src=\""+ppathHtml+"\">")


        print >>o, "</table>"

        print >>o, "<input type=\"button\" id=\"voir_"+self.name+"\" value=\"show details\" onClick=\"divaffiche('"+self.name+"')\" style=\"display:inline;\"/>"
        print >>o, "<input type=\"button\" id=\"cache_"+self.name+"\" value=\"hide details\" onClick=\"divcache('"+self.name+"')\" style=\"display:none;\"/>"
        print >>o, "<div id=\"popup_"+self.name+"\" style=\"display:none;margin:0 auto;\">"

        print >>o, "<table border=\"0\">"

        printValue(o,"Statistics of user predictions' expected confidences",self.UserPred_Confidence_Stats.strHtml(percent=True),False)
        printValue(o,"Statistics of reference predictions' expected confidences",self.RefPred_Confidence_Stats.strHtml(percent=True),False)

        printValue(o,"Statistics of user predictions' expected precisions",self.UserPred_Precision_Stats.strHtml(),False)
        printValue(o,"Statistics of reference predictions' expected precisions",self.RefPred_Precision_Stats.strHtml(),False)

        printValue(o,"User predictions' expected confidences/Reference predictions' expected confidences",strPercent(self.UserPred_Confidence_Stats.mean/self.RefPred_Confidence_Stats.mean))
        printValue(o,"User predictions' expected precisions/Reference predictions' expected precisions",strPercent(self.UserPred_Precision_Stats.mean/self.RefPred_Precision_Stats.mean))

        if computeSurceIntersection:

            printValue(o,"Details","",False)
    
            printValue(o,"Matching Ref->User",self.UserRefOnRef.strHtml(),False)
            printValue(o,"Matching User->Ref",self.UserRefOnUser.strHtml(),False)
    
            if self.eventsAvalable:
                printValue(o,"Matching Event->Ref",self.RefEventOnEvent.strHtml(),False)
                printValue(o,"Matching Event->User",self.UserEventOnEvent.strHtml(),False)
                printValue(o,"Matching Ref->Event",self.EventRefOnRef.strHtml(),False)
                printValue(o,"Matching User->Event",self.EventUserOnUser.strHtml(),False)

        print >>o, "</table></div>"

class Counter:
    def __init__(self,m):
        self.max = m
        self.v = 0
        self.last = time.time()
        self.begin = self.last
    def step(self):
        self.v = self.v + 1
        t = time.time()
        if t>self.last+1:
            print "[",self.v,"/",self.max,"]",
            self.last = t
    def finish(self):
        if time.time() - self.begin > 0.5:
            print "[done in ",time.time() - self.begin," seconds]"

def surfaceIntersection_sub(a1,a2,b1,b2):
    #return 1.0
    if b1==b2:
        if b1>=a1 and b1<=a2:
            return 1
        else:
            return 0
   
    l1 = max(a1,b1)
    l2 = min(a2,b2)
    if l2<=l1:
        return 0
    else:   
        if b1>=b2:
            raise Exception("b1>=b2")
        v = (l2-l1)/(b2-b1)
        return v
    
def surfaceIntersection(a,b,symbol,buildAnalyse=True):
    # (a^b)/b
    intersects = []
    counter = Counter(b.size())
    for i in b.data:
        counter.step();
        if i.symbol==symbol:
            bsearh = i.begin - a.maximumRange
            esearh = i.begin + b.maximumRange
            index = a.getIndexOfBefore(bsearh)
            coef = 1
            while index<a.size() and a.data[index].begin <= esearh:
                if a.data[index].symbol==symbol:
                    c = surfaceIntersection_sub(i.begin,i.end,a.data[index].begin,a.data[index].end)
                    coef = coef * (1 - c * a.data[index].confidence)
                index = index + 1
            coef = (1 - coef)  / i.confidence
            if coef>1:
                coef = 1
                #print c,
            #print "turns : ",turns
            intersects.append(coef)
    counter.finish()
    if buildAnalyse:
        return StatAnalisis(intersects)
    else:
        return intersects

def predictionTruth(ev,pr,symbol):
    t1 = []
    t2 = []
    multiPred = []
    counter = Counter(pr.size())
    for i in pr.data:
        counter.step();
        if i.symbol==symbol:
            index = ev.getIndexOfBefore(i.begin)
            num = 0
            while index<ev.size() and ev.data[index].begin <= i.end:
                if ev.data[index].symbol==symbol:
                    num = num + 1
                    if num>20:
                        break # test (disable multi pred)
                index = index + 1
            if num>0:
                multiPred.append(num)
                t2.append(1)
            else:
                t2.append(0)
            t1.append(i.confidence)
                
    counter.finish()
    return (t1,t2),multiPred

def confidence(ev,pr,symbol):
    counter = Counter(pr.size())
    good = 0
    for i in pr.data:
        counter.step();
        if i.symbol==symbol:
            index = ev.getIndexOfBefore(i.begin)
            while index<ev.size() and ev.data[index].begin <= i.end:
                if ev.data[index].symbol==symbol:
                    good = good + 1
                    break
                index = index + 1
    counter.finish()
    if len(pr.data)==0:
        return 0
    return float(good)/pr.size()
        
def support(ev,pr,symbol):
    counter = Counter(ev.size())
    good = 0
    numToCount = 0
    for i in ev.data:
        counter.step();
        if i.symbol==symbol:
            index = pr.getIndexOfBefore(i.begin-pr.maximumRange)
            while index<pr.size() and pr.data[index].begin <= i.end:
                if pr.data[index].symbol==symbol:
                    if pr.data[index].end>=i.end:
                        good = good + 1
                        break
                index = index + 1
            numToCount = numToCount + 1
    counter.finish()
    if numToCount==0:
        return 0
    return float(good)/numToCount

def buildReport(name,refEvents,refPred,userPred,description,descriptionExtra,details=True):
    rep = Report()
    rep.name = name

    if details:
        rep.refPred = refPred
        rep.userPred = userPred
    
    rep.description = description
    rep.descriptionExtra = descriptionExtra

    S = list(set([i.symbol for i in refPred.data]))

    if len(S)==0:
        return None
        #raise Exception("There is no reference predictions in " + name)

    if len(S)>1:
        raise Exception("There is several symbol of prediction (only one is needed) in " + name)
    
    rep.symbol = S[0]

    rep.nOfUserPred = userPred.size()
    rep.nOfRefPred = refPred.size()
    
    if refEvents!=None:
        rep.nOfRefEvent = refEvents.size(rep.symbol)
    else:
        rep.nOfRefEvent = "*no events file*"

    rep.UserPred_Confidence_Stats = StatAnalisis(userPred.getConfidenceList())
    rep.UserPred_Precision_Stats = StatAnalisis(userPred.getPrecisionList()) 

    rep.RefPred_Confidence_Stats = StatAnalisis(refPred.getConfidenceList())
    rep.RefPred_Precision_Stats = StatAnalisis(refPred.getPrecisionList()) 

    if computeSurceIntersection:
        print "surfaceIntersection of UserRefOnRef"
        rep.UserRefOnRef = surfaceIntersection(userPred,refPred,rep.symbol)
        print "UserRefOnUser of UserRefOnRef"
        rep.UserRefOnUser = surfaceIntersection(refPred,userPred,rep.symbol)
    
    rep.precUser = rep.UserPred_Precision_Stats.mean
    rep.precRef = rep.RefPred_Precision_Stats.mean
    
    if refEvents!=None:
        rep.eventsAvalable = True
        
        if computeSurceIntersection:
            print "RefEventOnEvent of UserRefOnRef"
            rep.RefEventOnEvent = surfaceIntersection(refPred,refEvents,rep.symbol)
            print "UserEventOnEvent of UserRefOnRef"
            rep.UserEventOnEvent = surfaceIntersection(userPred,refEvents,rep.symbol)
            print "EventRefOnRef of UserRefOnRef"
            rep.EventRefOnRef = surfaceIntersection(refEvents,refPred,rep.symbol)
            print "EventUserOnUser of UserRefOnRef"
            rep.EventUserOnUser = surfaceIntersection(refEvents,userPred,rep.symbol)

        rep.userCross,rep.userMultiPred = predictionTruth(refEvents,userPred,rep.symbol)
        rep.refCross,rep.refMultiPred = predictionTruth(refEvents,refPred,rep.symbol)

        rep.confUser = confidence(refEvents,userPred,rep.symbol)
        rep.confRef = confidence(refEvents,refPred,rep.symbol)
        rep.supportUser = support(refEvents,userPred,rep.symbol)
        rep.supportRef = support(refEvents,refPred,rep.symbol)
        
        
        rep.userMultiPred_left,rep.userMultiPred_height = integerHisto_leftheight(rep.userMultiPred)
        rep.refMultiPred_left,rep.refMultiPred_height = integerHisto_leftheight(rep.refMultiPred)
   
        if not details:
            rep.userCross = None
            rep.userMultiPred = None
            rep.refCross = None
            rep.refMultiPred = None 

    else:
        rep.eventsAvalable = False
        rep.userCross ="*no events file*"
        rep.refCross = "*no events file*"
        rep.RefEventOnEvent = "*no events file*"
        rep.UserEventOnEvent = "*no events file*"
        rep.EventRefOnRef = "*no events file*"
        rep.EventUserOnUser = "*no events file*"
        rep.confUser = "*no events file*"
        rep.confRef = "*no events file*"
        rep.supportUser = "*no events file*"
        rep.supportRef = "*no events file*"

    return rep

class UserConfigWindows:
    def __init__(self, master):
        self.good = False
        
        self.userPredDir = StringVar()
        self.userPredDir.set("dataset_refPred/")
        
        self.refPredDir = StringVar()
        self.refPredDir.set("dataset_refPred/")
        
        self.refEventDir = StringVar()
        self.refEventDir.set("dataset/")
        
        self.descDir = StringVar()
        self.descDir.set("dataset_desc/")
        
        self.reportPath = StringVar()
        self.reportPath.set("report.html")
        
        self.maxReport = StringVar()
        self.maxReport.set("10")

        self.frame = Frame(master)
        self.frame.pack()
        master.title("Evaluate Prediction -- configuration")
        
        row = 0

        self.screenLabel = Label(self.frame, text=screenText())
        self.screenLabel.grid(row = row,column = 0,columnspan=2)
        row = row + 1

        # ============

        self.label1 = Label(self.frame, text="User predictions directory :")
        self.label1.grid(row = row,column = 0)
        row = row + 1
        
        self.text1 = Entry(self.frame,textvariable=self.userPredDir,width=70)
        self.text1.grid(row = row,column = 0)
        
        self.button1 = Button(self.frame, text="Browse",width=12, command=self.browse_user)
        self.button1.grid(row = row,column = 1)
        row = row + 1
        
        # ============

        self.label2 = Label(self.frame, text="Reference predictions directory :")
        self.label2.grid(row = row,column = 0)
        row = row + 1
        
        self.text2 = Entry(self.frame,textvariable=self.refPredDir,width=70)
        self.text2.grid(row = row,column = 0)
        
        self.button2 = Button(self.frame, text="Browse",width=12, command=self.browse_ref)
        self.button2.grid(row = row,column = 1)
        row = row + 1
        
        # ============

        self.label3 = Label(self.frame, text="Events directory (optional) :")
        self.label3.grid(row = row,column = 0)
        row = row + 1
        
        self.text3 = Entry(self.frame,textvariable=self.refEventDir,width=70)
        self.text3.grid(row = row,column = 0)
        
        self.button3 = Button(self.frame, text="Browse",width=12, command=self.browse_event)
        self.button3.grid(row = row,column = 1)
        row = row + 1
        
        # ============

        self.label4 = Label(self.frame, text="Dataset descriptions directory (optional) :")
        self.label4.grid(row = row,column = 0)
        row = row + 1
        
        self.text4 = Entry(self.frame,textvariable=self.descDir,width=70)
        self.text4.grid(row = row,column = 0)
        
        self.button4 = Button(self.frame, text="Browse",width=12, command=self.browse_desc)
        self.button4.grid(row = row,column = 1)
        row = row + 1
        
        # ============

        self.label5 = Label(self.frame, text="Output report :")
        self.label5.grid(row = row,column = 0)
        row = row + 1
        
        self.text5 = Entry(self.frame,textvariable=self.reportPath,width=70)
        self.text5.grid(row = row,column = 0)
        
        self.button5 = Button(self.frame, text="Browse",width=12, command=self.browse_report)
        self.button5.grid(row = row,column = 1)
        row = row + 1
        
        self.label8 = Label(self.frame, text="Number of full report ( -1 for all reports) :")
        self.label8.grid(row = row,column = 0)
        row = row + 1

        self.text8 = Entry(self.frame,textvariable=self.maxReport,width=20)
        self.text8.grid(row = row,column = 0)
        row = row + 1
        
        # ==================

        self.button6 = Button(self.frame, text="Start analyse", command=self.analyse,width=12)
        self.button6.grid(row = row,column = 0,columnspan=2)
        row = row + 1

        self.button7 = Button(self.frame, text="Quit", command=self.frame.quit,width=12)
        self.button7.grid(row = row,column = 0,columnspan=2)
        row = row + 1

    def analyse(self):
        #self.button6.config(text="Analyse in progress")
        print self.userPredDir.get()
        print self.refPredDir.get()
        print self.reportPath.get()
        self.good = True
        self.frame.quit()
        
    def browse_event(self):
        text = tkFileDialog.askdirectory(title='Select events directory')
        if len(text)>0:
            self.refEventDir.set(text)
            
    def browse_desc(self):
        text = tkFileDialog.askdirectory(title='Select dataset descriptions directory')
        if len(text)>0:
            self.descDir.set(text)
        
    def browse_user(self):
        text = tkFileDialog.askdirectory(title='Select user predictions directory')
        if len(text)>0:
            self.userPredDir.set(text)
            if tkMessageBox.askyesno("Report name", "Auto set report name?"):
                (path, filename) = os.path.split(text)
                if re.search("^data_",filename):
                    r = os.path.join(path,"report_"+filename[(len("data_")):]+".html").replace("\\","/")
                else:
                    r = os.path.join(path,"report_"+filename+".html").replace("\\","/")
                self.reportPath.set(r)
    
    def browse_ref(self):
        text = tkFileDialog.askdirectory(title='Select reference predictions directory')
        if len(text)>0:
            self.refPredDir.set(text)
    
    def browse_report(self):
        text = tkFileDialog.asksaveasfilename(title='Select output report',defaultextension='.html',filetypes=(('Html File', '*.html'),('All Files', '*')))
        if len(text)>0:
            self.reportPath.set(text)
def main():
    global reportImagePath
    screen()
    

    root = Tk()
    userConfigWindows = UserConfigWindows(root)
    root.mainloop()

    if userConfigWindows.good:
        userPredDir = userConfigWindows.userPredDir.get()
        refPredDir = userConfigWindows.refPredDir.get()
        reportPath = userConfigWindows.reportPath.get()
        eventPath = userConfigWindows.refEventDir.get()
        descPath = userConfigWindows.descDir.get()
        maxWritingReports = int(userConfigWindows.maxReport.get())
    else:
        print "*stop*"
        return

    print "report path :",reportPath
    (reportpath, reportfilename) = os.path.split(reportPath)
    (reportshortname, reportextension) = os.path.splitext(reportfilename)
    reportImagePathHtml = reportshortname+"_images"
    reportImagePath = os.path.join(reportpath,reportImagePathHtml).replace("\\","/")
    if not os.path.isdir(reportImagePath):
        os.mkdir(reportImagePath)

    references = glob.glob(os.path.join(refPredDir,"*.pred"))

    print "Number of prediction references :",len(references)

    reportsList = []

    noUserPred = 0
    index = 0
    beginTime = time.time()
    
    pb1 = PB("",300,50)
    pb1.title("compute scores [operation 1/2]")
    pb1.open()
    pb1.update(0)
    index2 = 0
    for ref in references:
        index = index + 1
        index2 = index2 + 1
        pb1.update(float(index2)/len(references))

        print "Reference :",ref,"[",index,"/",len(references),"]"
        (filepath, filename) = os.path.split(ref)
        (shortname, extension) = os.path.splitext(filename)

        if debug:
            if index>3:
                break

        #if shortname!="part_25_1": # for debug
        #    continue

        userPredPath = os.path.join(userPredDir,shortname+".pred").replace("\\","/")
        print "User prediction file :",userPredPath

        eventsPath = os.path.join(eventPath,shortname+".event").replace("\\","/")
        print "Event file :",eventsPath
        
        ruleComplexityPath = os.path.join(descPath,shortname+".txt").replace("\\","/")
        print "Description of rule complexity path :",ruleComplexityPath
        
        extraInfoPath = os.path.join(userPredDir,shortname+"_info.txt").replace("\\","/")
        
        # tmp debug
        extraInfoPath = extraInfoPath.replace("_2_","_1_")
        
        print "extra info path :",extraInfoPath

        if not os.path.isfile(userPredPath):
            print "User predictions no found :",userPredPath
            index = index - 1
        else:
            print "User predictions found"

            noUserPred = noUserPred + 1
            
            if not os.path.isfile(ruleComplexityPath):
                print "Description of rule complexity no found"
                description = None
            else:
                fdesc = open(ruleComplexityPath,"r")
                description = {}
                for l in fdesc:
                    #print "[debug] l : ",l
                    g = re.search("\"(?P<name>[A-Za-z0-9\s]+)\"\s+(?P<value>\S+)", l)
                    if g!=None:
                        #print "[debug] g : ",g.groups()
                        description[g.group("name")] = float(g.group("value"))
                fdesc.close()
                        
            if not os.path.isfile(extraInfoPath):
                print "Extra description of rule complexity no found"
                descriptionExtra = None
            else:
                fdesc = open(extraInfoPath,"r")
                descriptionExtra = {}
                for l in fdesc:
                    #print "[debug] l : ",l
                    g = re.search("\"(?P<name>[A-Za-z0-9\s]+)\"\s+(?P<value>\S+)", l)
                    if g!=None:
                        #print "[debug] g : ",g.groups()
                        descriptionExtra[g.group("name")] = float(g.group("value"))
                fdesc.close()

            userPred = Predictions()
            userPred.loadFromFile(userPredPath)

            referencePred = Predictions()
            referencePred.loadFromFile(ref)

            referenceEvents = None
            if os.path.isfile(eventsPath):
                referenceEvents = Predictions()
                referenceEvents.loadFromFileEvent(eventsPath)

            if maxWritingReports>= 0 and index > maxWritingReports:
                details = False
            else:
                details = True
                
            r =buildReport(shortname,referenceEvents,referencePred,userPred,description=description,details=details,descriptionExtra=descriptionExtra)
            
            if r!=None:
                reportsList.append(r)
            else:
                index = index - 1
                
    endTime = time.time()
     
    if len(reportsList)==0:
         print "ERROR : There is not valid subset."
         return
     
    print "writhing report"
    
    pb1.title("writing report [operation 2/2]")
    pb1.update(0)

    atLeastOneEventAvalable = False
    for rr in reportsList:
        if rr.eventsAvalable:
            atLeastOneEventAvalable = True
            break

    report = open(reportPath,"w")

    print >>report, "<html>"
    print >>report, "<head>"
    print >>report, "<title>Data Set Specification</title>"
    print >>report, "<script type=\"text/javascript\">"
    print >>report, "<!--"
    print >>report, "function divaffiche(name){"
    print >>report, "document.getElementById(\"popup_\"+name).style.display = \"block\";"
    print >>report, "document.getElementById(\"cache_\"+name).style.display = \"inline\";"
    print >>report, "document.getElementById(\"voir_\"+name).style.display = \"none\";"
    print >>report, "} "
    print >>report, "function divcache(name){"
    print >>report, "document.getElementById(\"popup_\"+name).style.display = \"none\";"
    print >>report, "document.getElementById(\"cache_\"+name).style.display = \"none\";"
    print >>report, "document.getElementById(\"voir_\"+name).style.display = \"inline\";"
    print >>report, "} "
    print >>report, "-->"
    print >>report, "</script>"
    print >>report, "</head>"
    print >>report, "<body>"

    print >>report, "<div style=\"width:500px;margin:0 auto\" >"
    print >>report, "<span style=\"font-size:25px\">Temporal Data Set Evaluation V1.0</span><br>"
    print >>report, "<span style=\"font-size:20px\">Mathieu Guillame-Bert</span><br>"
    print >>report, "PhD Student - INRIA Rh�ne Alpes<br>"
    print >>report, "<br>"
    print >>report, "Mail : mathieu.guillame-bert@inrialpes.fr<br>"
    print >>report, "Web site : http://www-prima.imag.fr/guillame-bert<br>"
    print >>report, "<br>"
    print >>report, "Date of generation : " , time.asctime(), "<br>"
    print >>report, "</div>"

    print >>report, "<HR>"

    print >>report, "<span style=\"font-size:20px\">Notation :</span><br><br>"
    print >>report, "<table border=\"0\">"
    
    
    printValue(report,"User_Conf[i]","confidence of user's predictions on subset i i.e probability of a preduction to be true")
    printValue(report,"Ref_Conf[i]","confidence of reference's predictions on subset i i.e probability of a preduction to be true")
    
    printValue(report,"User_Supp[i]","support of user's predictions on subset i i.e probability of an event to be predicted")
    printValue(report,"Ref_Supp[i]","support of reference's predictions on subset i i.e probability of an event to be predicted")
    
    printValue(report,"User_Prec[i]","precision of user's predictions on subset i i.e. temporal accuracy of the prediction")
    printValue(report,"Ref_Prec[i]","precision of reference's predictions on subset i i.e. temporal accuracy of the prediction")

    printValue(report,"mean(l)","mean of a list's values i.e sum(l)/size(l)")
    
    printValue(report,"Precision","Precision (or temporal precision) of a prediction is the " + Prediction.precisionTypeMin + " of this prediction")
    
    print >>report, "</table>"

    print >>report, "<HR>"

    print >>report, "<span style=\"font-size:20px\">Global results:</span><br><br>"

    print >>report, "<table border=\"0\">"

    if debug:
        for rr in reportsList:
            rr.confUser = random.random()
            rr.confRef = rr.confUser + random.random() * 0.1
            rr.supportUser = random.random()
            rr.supportRef = rr.supportUser + random.random() * 0.1
            rr.UserPred_Precision_Stats.mean = random.random()
            rr.RefPred_Precision_Stats.mean = rr.UserPred_Precision_Stats.mean + random.random() * 0.1

    printValue(report,"Number of evaluation subsets",len(reportsList))
    
    if not atLeastOneEventAvalable:
        printValue(report,"Information : There is not even database. Real confidence and support are not computed","")
    
    printValue(report,"Duration of evaluation",("%.2f"%(endTime-beginTime))+"s")

    printValue(report,"&nbsp;","&nbsp;",False)

    printValue(report,"User's predictions directory",userPredDir)
    printValue(report,"Reference's predictions directory",refPredDir)
    printValue(report,"Events directory",eventPath)
    printValue(report,"Dataset Descriptions directory",descPath)
    printValue(report,"Output report directory",reportPath)
    
    printValue(report,"&nbsp;","&nbsp;",False)

    if atLeastOneEventAvalable:
        extra = "i.e. statistics of { User_Conf[i]/Ref_Conf[i] for i = 1...N } with N the number of subsets"
        d = [rr.confUser/rr.confRef for rr in reportsList if rr.eventsAvalable]
        printValue(report,"Ratio User's predictions' estimated confidence/Reference's predictions' estimated confidence",StatAnalisis(d,buildFig=True).strHtml(percent=True,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml),False,extra=extra)
    
        printValue(report,"","",False)
    
        extra = "i.e. statistics of { User_Supp[i]/Ref_Supp[i] for i = 1...N } with N the number of subsets"
        d = [rr.supportUser/rr.supportRef for rr in reportsList if rr.eventsAvalable]
        printValue(report,"Ratio User's predictions' estimated support/Reference's predictions' estimated support",StatAnalisis(d,buildFig=True).strHtml(percent=True,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml),False,extra=extra)
    
        printValue(report,"","",False)

    extra = "i.e. statistics of { User_Prec[i]/Ref_Prec[i] for i = 1...N } with N the number of subsets"
    d = [rr.UserPred_Precision_Stats.mean/rr.RefPred_Precision_Stats.mean for rr in reportsList]
    printValue(report,"Ratio User's predictions' precision/Reference's predictions' precision",StatAnalisis(d,buildFig=True).strHtml(percent=True,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml),False,extra=extra)

    printValue(report,"","",False)

    if atLeastOneEventAvalable:
        
        extra = "i.e. statistics of { (User_Conf[i]-Ref_Conf[i])/Ref_Conf[i] for i = 1...N } with N the number of subsets"
        d = [(rr.confUser-rr.confRef)/rr.confRef for rr in reportsList if rr.eventsAvalable]
        printValue(report,"Gain User's predictions' estimated confidence/Reference's predictions' estimated confidence",StatAnalisis(d,buildFig=True).strHtml(percent=True,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml),False,extra=extra)
    
        printValue(report,"","",False)
    
        extra = "i.e. statistics of { (User_Supp[i]-Ref_Supp[i])/Ref_Supp[i] for i = 1...N } with N the number of subsets"
        d = [(rr.supportUser-rr.supportRef)/rr.supportRef for rr in reportsList if rr.eventsAvalable]
        printValue(report,"Gain User's predictions' estimated support/Reference's predictions' estimated support",StatAnalisis(d,buildFig=True).strHtml(percent=True,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml),False,extra=extra)
    
        printValue(report,"","",False)
        
        extra = "i.e. statistics of { (User_Prec[i]-Ref_Prec[i])/Ref_Prec[i] for i = 1...N } with N the number of subsets"
        d = [(rr.UserPred_Precision_Stats.mean-rr.RefPred_Precision_Stats.mean)/rr.RefPred_Precision_Stats.mean for rr in reportsList]
        printValue(report,"Gain User's predictions' precision/Reference's predictions' precision",StatAnalisis(d,buildFig=True).strHtml(percent=True,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml),False,extra=extra)
        printValue(report,"","",False)

    #print >>report,"</td></tr>"
    
    extra = ""
    d = [rr.nOfUserPred for rr in reportsList]
    printValue(report,"Number of user's predictions",StatAnalisis(d,buildFig=True).strHtml(percent=False,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml),False,extra=extra)
    printValue(report,"","",False)
    
    extra = ""
    d = [rr.nOfRefPred for rr in reportsList]
    printValue(report,"Number of reference predictions",StatAnalisis(d,buildFig=True).strHtml(percent=False,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml),False,extra=extra)
    printValue(report,"","",False)
    
    extra = ""
    d = [ rr.nOfUserPred / rr.nOfRefPred for rr in reportsList if rr.nOfRefPred >0 ]
    printValue(report,"Gain of number of user's predictions / number of reference predictions",StatAnalisis(d,buildFig=True).strHtml(percent=True,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml),False,extra=extra)
    printValue(report,"","",False)
    
    if atLeastOneEventAvalable:
        extra = ""
        d = [rr.nOfUserPred / rr.nOfRefEvent for rr in reportsList]
        printValue(report,"Number of user's predictions / number of events",StatAnalisis(d,buildFig=True).strHtml(percent=True,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml),False,extra=extra)
        printValue(report,"","",False)
        
        extra = ""
        d = [rr.nOfRefPred / rr.nOfRefEvent for rr in reportsList]
        printValue(report,"Number of reference prediction / number of events",StatAnalisis(d,buildFig=True).strHtml(percent=True,reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml),False,extra=extra)
        printValue(report,"","",False)

    print >>report, "</table>"


    # ========== conf/sup ==========

    if atLeastOneEventAvalable:

        print >>report, "<table border=\"0\">"
    
        print >>report,"<tr align=\"center\"><td>"
        print >>report,"&nbsp;"
        print >>report,"</td><td>"
        print >>report,"Ratio"
        print >>report,"<br> i.e user/ref "
        print >>report,"</td><td>"
        print >>report,"Gain"
        print >>report,"<br> i.e (user-ref)/ref "
        print >>report,"</td><td>"
        print >>report,"Bond"
        print >>report,"<br> i.e user &rarr; ref "
        print >>report,"</td></tr>"
    
        
        print >>report,"<tr align=\"center\"><td>"
        print >>report,"Confidence/Support"
        print >>report,"</td><td>"
        
        text = ""
        
        fig = plt.figure(figsize=(6,5))
        ax = fig.add_axes(border)
        X = [100*rr.confUser/rr.confRef for rr in reportsList if rr.eventsAvalable]
        Y = [100*rr.supportUser/rr.supportRef for rr in reportsList if rr.eventsAvalable]
        ax.scatter(X,Y,c="black")
        #ax.set_yscale('log')
        ax.set_xlabel('confidence ratio (%)')
        ax.set_ylabel('support ratio (%)')
        ax.set_xlim([min(0,ax.get_xlim()[0]),max(100,ax.get_xlim()[1])])
        ax.set_ylim([min(0,ax.get_ylim()[0]),max(100,ax.get_ylim()[1])])
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.yaxis.set_major_locator(MaxNLocator(5))
        
        name = "comp_confsup_ratio.png"
        ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
        ppath = os.path.join(reportImagePath,name).replace("\\","/")
        
        fig.savefig(ppath,dpi=50)
        plt.close(fig)
        text = text + "<img src=\""+ppathHtml+"\"> "
    
        extra = ""
        print >>report,text
    
        print >>report,"</td><td>"
    
        text = ""
        fig = plt.figure(figsize=(6,5))
        ax = fig.add_axes(border)
        X = [100*(rr.confUser-rr.confRef)/rr.confRef for rr in reportsList]
        Y = [100*(rr.supportUser-rr.supportRef)/rr.supportRef for rr in reportsList]
        ax.scatter(X,Y,c="black")
        #ax.set_yscale('log')
        ax.set_xlabel('confidence gain (%)')
        ax.set_ylabel('support gain (%)')
        ax.set_xlim([min(0,ax.get_xlim()[0]),max(100,ax.get_xlim()[1])])
        ax.set_ylim([min(0,ax.get_ylim()[0]),max(100,ax.get_ylim()[1])])
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.yaxis.set_major_locator(MaxNLocator(5))
  
        name = "comp_confsup.png"
        ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
        ppath = os.path.join(reportImagePath,name).replace("\\","/")
        
        fig.savefig(ppath,dpi=50)
        plt.close(fig)
        text = text + "<img src=\""+ppathHtml+"\"> "

        extra = ""
        print >>report,text
    
        print >>report,"</td><td>"
    
        text = ""
    
        fig = plt.figure(figsize=(6,5))
        ax = fig.add_axes(border)
        D = [([100*rr.confUser,100*rr.confRef],[100*rr.supportUser,100*rr.supportRef]) for rr in reportsList]
    
        first = True
        for d in D:
            ax.plot(d[0],d[1],"-",color="black")
            if first:
                ax.scatter(d[0][0],d[1][0],c="red",label="user")
                ax.scatter(d[0][1],d[1][1],c="blue",label="reference")
            else:
                ax.scatter(d[0][0],d[1][0],c="red",label="_nolegend_")
                ax.scatter(d[0][1],d[1][1],c="blue",label="_nolegend_")
            first = False
    
        #ax.set_yscale('log')
        ax.set_xlabel('confidence (%)')
        ax.set_ylabel('support (%)')
        ax.set_xlim([min(0,ax.get_xlim()[0]),max(100,ax.get_xlim()[1])])
        ax.set_ylim([min(0,ax.get_ylim()[0]),max(100,ax.get_ylim()[1])])
        ax.legend(scatterpoints=1)
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.yaxis.set_major_locator(MaxNLocator(5))
        
        name = "comp_confsup_2.png"
        ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
        ppath = os.path.join(reportImagePath,name).replace("\\","/")
        
        fig.savefig(ppath,dpi=50)
        plt.close(fig)
        text = text + "<img src=\""+ppathHtml+"\"> "

        extra = ""
        
        print >>report,text
    
        print >>report,"</td></tr>"
    
        # ========== conf/Prec ==========
    
        print >>report,"<tr align=\"center\"><td>"
        print >>report,"Confidence/"+Prediction.precisionType
        print >>report,"</td><td>"
    
        text = ""
        
        fig = plt.figure(figsize=(6,5))
        ax = fig.add_axes(border)
        X = [100*rr.confUser/rr.confRef for rr in reportsList]
        Y = [100*rr.UserPred_Precision_Stats.mean/rr.RefPred_Precision_Stats.mean for rr in reportsList]
        if len(X)!=0:
            ax.scatter(X,Y,c="black")
        #ax.set_yscale('log')
        ax.set_xlabel('confidence ratio (%)')
        ax.set_ylabel(Prediction.precisionTypeMin+" ratio (%)")
        ax.set_xlim([min(0,ax.get_xlim()[0]),max(100,ax.get_xlim()[1])])
        ax.set_ylim([min(0,ax.get_ylim()[0]),max(100,ax.get_ylim()[1])])
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.yaxis.set_major_locator(MaxNLocator(5))
        
        name = "comp_confrange_ratio.png"
        ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
        ppath = os.path.join(reportImagePath,name).replace("\\","/")
        
        fig.savefig(ppath,dpi=50)
        plt.close(fig)
        text = text + "<img src=\""+ppathHtml+"\"> "

        
        extra = ""
        print >>report,text
    
        print >>report,"</td><td>"
    
        text = ""
    
        fig = plt.figure(figsize=(6,5))
        ax = fig.add_axes(border)
        X = [100*(rr.confUser-rr.confRef)/rr.confRef for rr in reportsList]
        Y = [100*(rr.UserPred_Precision_Stats.mean-rr.RefPred_Precision_Stats.mean)/rr.RefPred_Precision_Stats.mean for rr in reportsList]
        if len(X)!=0:
            ax.scatter(X,Y,c="black")
        #ax.set_yscale('log')
        ax.set_xlabel('confidence gain (%)')
        ax.set_ylabel(Prediction.precisionTypeMin+" gain (%)")
        ax.set_xlim([min(0,ax.get_xlim()[0]),max(100,ax.get_xlim()[1])])
        ax.set_ylim([min(0,ax.get_ylim()[0]),max(100,ax.get_ylim()[1])])
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.yaxis.set_major_locator(MaxNLocator(5))
        
        name = "comp_confrange.png"
        ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
        ppath = os.path.join(reportImagePath,name).replace("\\","/")
        
        fig.savefig(ppath,dpi=50)
        plt.close(fig)
        text = text + "<img src=\""+ppathHtml+"\"> "

        extra = ""
        print >>report,text
    
        print >>report,"</td><td>"
    
        text = ""
    
        fig = plt.figure(figsize=(6,5))
        ax = fig.add_axes(border)
        D = [([100*rr.confUser,100*rr.confRef],[rr.UserPred_Precision_Stats.mean,rr.RefPred_Precision_Stats.mean]) for rr in reportsList]
    
        first = True
        for d in D:
            ax.plot(d[0],d[1],"-",color="black")
            if first:
                ax.scatter(d[0][0],d[1][0],c="red",label="user")
                ax.scatter(d[0][1],d[1][1],c="blue",label="reference")
            else:
                ax.scatter(d[0][0],d[1][0],c="red",label="_nolegend_")
                ax.scatter(d[0][1],d[1][1],c="blue",label="_nolegend_")
            first = False
    
        #ax.set_yscale('log')
        ax.set_xlabel('confidence (%)')
        ax.set_ylabel(Prediction.precisionTypeMin)
        ax.set_xlim([min(0,ax.get_xlim()[0]),max(100,ax.get_xlim()[1])])
        #ax.set_ylim([min(0,ax.get_ylim()[0]),max(100,ax.get_ylim()[1])])
        ax.legend(scatterpoints=1)
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.yaxis.set_major_locator(MaxNLocator(5))
        
        name = "comp_confrange_2.png"
        ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
        ppath = os.path.join(reportImagePath,name).replace("\\","/")
        
        fig.savefig(ppath,dpi=50)
        plt.close(fig)
        text = text + "<img src=\""+ppathHtml+"\"> "
        
        extra = ""
        print >>report,text
    
        print >>report,"</td></tr>"
    
        # ========== Prec/sup ==========
    
        print >>report,"<tr align=\"center\"><td>"
        print >>report,Prediction.precisionType+"/Support"
        print >>report,"</td><td>"
    
    
        text = ""
        
        fig = plt.figure(figsize=(6,5))
        ax = fig.add_axes(border)
        X = [100*rr.UserPred_Precision_Stats.mean/rr.RefPred_Precision_Stats.mean for rr in reportsList]
        Y = [100*rr.supportUser/rr.supportRef for rr in reportsList]
        if len(X)!=0:
            ax.scatter(X,Y,c="black")
        #ax.set_yscale('log')
        ax.set_xlabel(Prediction.precisionTypeMin+' ratio (%)')
        ax.set_ylabel('support ratio (%)')
        ax.set_xlim([min(0,ax.get_xlim()[0]),max(100,ax.get_xlim()[1])])
        ax.set_ylim([min(0,ax.get_ylim()[0]),max(100,ax.get_ylim()[1])])
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.yaxis.set_major_locator(MaxNLocator(5))
        
        name = "comp_rangesup_ratio.png"
        ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
        ppath = os.path.join(reportImagePath,name).replace("\\","/")   
        fig.savefig(ppath,dpi=50)
        plt.close(fig)
        
        text = text + "<img src=\""+ppathHtml+"\"> "
    
        extra = ""
        print >>report,text
        print >>report,"</td><td>"
    
        text = ""
    
        fig = plt.figure(figsize=(6,5))
        ax = fig.add_axes(border)
        X = [100*(rr.UserPred_Precision_Stats.mean-rr.RefPred_Precision_Stats.mean)/rr.RefPred_Precision_Stats.mean for rr in reportsList]
        Y = [100*(rr.supportUser-rr.supportRef)/rr.supportRef for rr in reportsList]
        if len(X)!=0:
            ax.scatter(X,Y,c="black")
        #ax.set_yscale('log')
        ax.set_xlabel(Prediction.precisionTypeMin+' gain (%)')
        ax.set_ylabel('support gain (%)')
        ax.set_xlim([min(0,ax.get_xlim()[0]),max(100,ax.get_xlim()[1])])
        ax.set_ylim([min(0,ax.get_ylim()[0]),max(100,ax.get_ylim()[1])])
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.yaxis.set_major_locator(MaxNLocator(5))
        
        name = "comp_rangesup.png"
        ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
        ppath = os.path.join(reportImagePath,name).replace("\\","/")
        
        fig.savefig(ppath,dpi=50)
        plt.close(fig)
        text = text + "<img src=\""+ppathHtml+"\"> "
        
        extra = ""
        print >>report,text
        print >>report,"</td><td>"
    
        text = ""
    
        fig = plt.figure(figsize=(6,5))
        ax = fig.add_axes(border)
        D = [([rr.UserPred_Precision_Stats.mean,rr.RefPred_Precision_Stats.mean],[100*rr.supportUser,100*rr.supportRef]) for rr in reportsList]
    
        first = True
        for d in D:
            ax.plot(d[0],d[1],"-",color="black")
            if first:
                ax.scatter(d[0][0],d[1][0],c="red",label="user")
                ax.scatter(d[0][1],d[1][1],c="blue",label="reference")
            else:
                ax.scatter(d[0][0],d[1][0],c="red",label="_nolegend_")
                ax.scatter(d[0][1],d[1][1],c="blue",label="_nolegend_")
            first = False
    
        #ax.set_yscale('log')
        ax.set_xlabel(Prediction.precisionTypeMin)
        ax.set_ylabel('support (%)')
        #ax.set_xlim([min(0,ax.get_xlim()[0]),max(100,ax.get_xlim()[1])])
        ax.set_ylim([min(0,ax.get_ylim()[0]),max(100,ax.get_ylim()[1])])
        ax.legend(scatterpoints=1)
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.yaxis.set_major_locator(MaxNLocator(5))
        
        name = "comp_rangesup_2.png"
        ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
        ppath = os.path.join(reportImagePath,name).replace("\\","/")
        
        fig.savefig(ppath,dpi=50)
        plt.close(fig)
        text = text + "<img src=\""+ppathHtml+"\"> "
        
        extra = ""
        print >>report,text
        print >>report,"</td></tr>"
    
        print >>report, "</table>"

    # =============== multi predictions ==========
    if atLeastOneEventAvalable:
        print >>report, "<table border=\"0\">"
        maxSize = max([len(rr.userMultiPred_height) for rr in reportsList])
        left = range(maxSize)
        means = [0. for i in left]
        for rr in reportsList:
            for i in range(len(rr.userMultiPred_height)):
                means[i] = means[i] + rr.userMultiPred_height[i]
                
        for i in range(len(means)):
            means[i] = means[i] / len(reportsList)

           
        maxSize2 = max([len(rr.refMultiPred_height) for rr in reportsList])
        left2 = range(maxSize2)
        means2 = [0. for i in left2]
        for rr in reportsList:
            for i in range(len(rr.refMultiPred_height)):
                means2[i] = means2[i] + rr.refMultiPred_height[i]
                
        for i in range(len(means2)):
            means2[i] = means2[i] / len(reportsList)
            
        img = integerHisto(reportImagePath=reportImagePath,reportImagePathHtml=reportImagePathHtml\
                           ,left=left,height=means\
                           ,leftp=left2,heightp=means2,maxX=50)
        extra = ""       
        printValue(report,"Mean of number of predictions of a single event",img,False,extra=extra)

        print >>report, "</table>"

    # ====== cross with complexity description ===
     
    if atLeastOneEventAvalable:
        
        
        descriptions = set()
        for rr in reportsList:
            if rr.description!=None:
                for ii in rr.description.keys():
                    descriptions.add(ii)
  
        descriptionExtra = set()
        for rr in reportsList:
            if rr.descriptionExtra!=None:
                for ii in rr.descriptionExtra.keys():
                    descriptionExtra.add(ii)                  
   
        text = ""
        for d in descriptions:
            if text!="":
                text = text + ", "
            text = text + d
        
        print >>report, "<table border=\"0\">"    
        printValue(report,"Descriptions",text)
        print >>report, "</table>"
        
        text = ""
        for d in descriptionExtra:
            if text!="":
                text = text + ", "
            text = text + d
        
        print >>report, "<table border=\"0\">"    
        printValue(report,"Descriptions extra",text)
        print >>report, "</table>"
        
        datasetSources = ["user","reference","ratio user-reference"]
        reportmeasures = ["confidence","support","precision"]
        
        print >>report, "<table border=\"0\">"
        
        print >>report,"<tr align=\"center\">"
        print >>report,"<td>&nbsp;</td>"
        print >>report,"<td><strong>User</strong></td>"
        print >>report,"<td><strong>Reference</strong></td>"
        print >>report,"<td><strong>User/Reference ratio</strong></td>"
        print >>report,"</tr>"
        
        for d in descriptions:
            for de in descriptionExtra:
                title = "Correlation between " + d + " and " + de
                text = ""
                print >> report, "<tr align=\"center\"><td valign=\"top\"><strong> "+title+" </strong></td>"              
                    
                # report [test sur description] -> X,Y
                X = []
                Y = []
                for rr in reportsList:
                    if rr.description!=None and rr.descriptionExtra!=None:
                        if rr.description.has_key(d) and rr.descriptionExtra.has_key(de):
                            X.append(rr.description[d])
                            Y.append(rr.descriptionExtra[de])
                      
                fig = plt.figure(figsize=(6,5))
                ax = fig.add_axes(border)
                     
                ax.scatter(X,Y,c="green")
                
                ax.set_xlabel(d)
                ax.set_ylabel(de)
                    
                #ax.legend(loc=3,scatterpoints=1)
                ax.xaxis.set_major_locator(MaxNLocator(5))
                ax.yaxis.set_major_locator(MaxNLocator(5))
                
                name = "cross_"+d+"_"+de+".png"
                ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
                ppath = os.path.join(reportImagePath,name).replace("\\","/")
                
                fig.savefig(ppath,dpi=50)
                plt.close(fig)

                print >> report, "<td> <img src=\""+ppathHtml+"\"> </td>"

                print >> report, "<tr>"

        for d in descriptions:
            for rm in reportmeasures:
                title = "Correlation between " + d + " and " + rm
                text = ""
                
                print >> report, "<tr align=\"center\"><td valign=\"top\"><strong> "+title+" </strong></td>"

                for ss in datasetSources:

                    useYPercent = rm in ["confidence","support"]

                    if ss == "ratio user-reference":
                        useYPercent = True                
                    
                    # report [test sur description] -> X,Y
                    X = []
                    Y = []
                    for rr in reportsList:
                        if rr.description!=None:
                            if rr.description.has_key(d):
                                v = rr.description[d]
                                X.append(v)
                                if useYPercent:
                                    Y.append(100*rr.getValue(ss,rm))
                                else:
                                    Y.append(rr.getValue(ss,rm))
                      
                    fig = plt.figure(figsize=(6,5))
                    ax = fig.add_axes(border)
                    
                    if ss=="user":
                        c="red"
                    elif ss=="reference":
                        c="blue"
                    else:
                        c="green"
                        
                    ax.scatter(X,Y,c=c,label=ss)
                    
                    ax.set_xlabel(d)

                    if useYPercent:
                        ax.set_ylim([min(0,ax.get_ylim()[0]),max(100,ax.get_ylim()[1])])
                        if ss == "ratio user-reference":
                            ax.set_ylabel(rm + " ratio (%)")
                        else:
                            ax.set_ylabel(rm + " (%)")
                    else:
                        ax.set_ylabel(rm)
                        
                    #ax.legend(loc=3,scatterpoints=1)
                    ax.xaxis.set_major_locator(MaxNLocator(5))
                    ax.yaxis.set_major_locator(MaxNLocator(5))
                    
                    name = "cross_"+d+"_"+rm+"_"+ss+".png"
                    ppathHtml = os.path.join(reportImagePathHtml,name).replace("\\","/")
                    ppath = os.path.join(reportImagePath,name).replace("\\","/")
                    
                    fig.savefig(ppath,dpi=50)
                    plt.close(fig)
                    #text = text + "<img src=\""+ppathHtml+"\"> "
    
                    print >> report, "<td> <img src=\""+ppathHtml+"\"> </td>"

                print >> report, "<tr>"
                #printValue(report,title,text,False)

        print >>report, "</table>"

    print >>report, "<HR>"

    print >>report, "<strong>List of subsets : </strong>"

    first = True
    index = 0
    for rr in reportsList:
        if not first:
            print >>report, ", "

        if maxWritingReports>= 0 and index>=maxWritingReports:
            print >>report, rr.name+" (report not generated)"
        else:
            print >>report, "<a href=\"#"+rr.name+"\">"+rr.name+"</a>"

        index = index + 1
        first = False

    maxcnt = len(reportsList)
    if maxWritingReports>=0 and maxWritingReports>maxWritingReports:
        maxcnt = maxWritingReports
    
    counter = Counter(maxcnt)
    index = 0
    
    #reportsList = []

    for rr in reportsList:
        counter.step()
        index = index + 1
        
        pb1.update((float(index)/maxcnt))
        
        if maxWritingReports>= 0 and index>maxWritingReports:
            break  
        
        print >>report, "<HR>"
        print >>report, "<a name=\""+rr.name+"\"></a>"
        rr.write(report,reportImagePath,reportImagePathHtml)
        report.flush()
        
    pb1.close()
    counter.finish()

    print >>report, "<body>"

    report.close()

    
if __name__ == "__main__":
    main()

